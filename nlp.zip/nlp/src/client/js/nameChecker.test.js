const checkForName = require('./checkForName');
test('test that name included results alert', () => {
    expect(checkForName("Picard")).toBe(document.getElementById('results').innerHTML != null);
  });
